secret_key = 'django-insecure-3q=hnr4@32g8a0-xum0(_!syq)m=!6zh@504pn57+0tsoh9065'
